package tw.tingyen.model;

public interface IMemberDao {
	public Member queryMemberById(int memberID);
}
