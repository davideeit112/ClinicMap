package tw.tingyen.model;

public interface IMemberService {
	public Member queryMemberById(int memberID);
}
